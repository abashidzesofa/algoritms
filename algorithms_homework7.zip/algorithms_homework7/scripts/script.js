'use strict';

const myStack = () => {
   const stack = new Array(7);
   let size = 0;
   let minStack = [];

const getSize = () => size;
const isEmpty = () => size === 0;

const getMin = () => {
   if (minStack.length === 0) {
      return null; 
   }
   return minStack[minStack.length - 1]; 
};

const push = data => {
   if (size === stack.length) {
   throw new Error("Stack overflow");
   }
   stack[size++] = data;

   if (minStack.length === 0 || data <= minStack[minStack.length - 1]) {
      minStack.push(data); 
   }
};

const pop = () => {
   if (size === 0) {
   return null;
   }
   let data = stack[--size];
   stack[size] = null;

   if (data === minStack[minStack.length - 1]) {
      minStack.pop(); 
   }
   return data;
};
const peek = () => {
   if (size === 0) {
      return null;
   }
   return stack[size -1]
}

const search =  data => {
   for (let i = 0; i < size; i++) {
      if (stack[i] === data) {
         return size - i;
      }
   }
   return -1;
}


const toStringMethod = () => {
   return size === 0 
   ? "[]" 
   : `[${stack.slice(0, size).join(", ")}]`;
};

return {
   getSize,
   isEmpty,
   push,
   pop,
   peek,
   search,
   getMin,
   toString: toStringMethod,
};
}

const stack = myStack();
stack.push('A');
stack.push('B');
stack.push('C');

console.log(stack.toString());

console.log('Peek:', stack.peek());

console.log('Ищем B:', stack.search('B')); 

console.log('Удаленный элемент :', stack.pop());

const minStack = myStack()
minStack.push(12);
minStack.push(7);
minStack.push(29);
minStack.push(1);


console.log(minStack.toString()); 
console.log('Минимальное значение стека : ', minStack.getMin());
console.log('Удаленный элемент :', minStack.pop());
console.log('Минимальное значение стека : ', minStack.getMin()); 