'use strict';



// Быстрая сортировка


const array = [];
for (let i = 0; i < 30; i++) {
   array.push(Math.floor(Math.random() * 31));
}


const quickSort = (arr, start, end) => {

   if (start < end) {
      let pivotIndex = helper(arr, start, end);
      quickSort(arr, start, pivotIndex - 1);
      quickSort(arr, pivotIndex + 1, end);
   }
return arr;
}


const helper = (arr, start, end) => {

   let pivotIndex = end;
   let pivot = arr[end];
   for (let i = start; i < pivotIndex -1; i++) {
      if (arr[i] >= pivot) {
         swap(arr, pivotIndex, pivotIndex -1);
         pivotIndex --;
         swap(arr, i, pivotIndex + 1);
         i --;
      }
   }
   if (arr[pivotIndex -1] > pivot) {
      swap(arr, pivotIndex, pivotIndex -1)
      pivotIndex --;
   }

   return pivotIndex;

}


const swap = (arr, first, second) => {

   let valueBox = arr[first];
   arr[first] = arr[second];
   arr[second] = valueBox;

}

console.log(quickSort(array, 0, array.length - 1));
