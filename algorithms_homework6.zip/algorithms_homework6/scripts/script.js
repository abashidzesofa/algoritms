'use strict';


const build_dictionary = str => {
   const alphabet = 'abcdefghijklmnopqrstuvwxyz';
   const new_array = new Array(alphabet.length).fill(0);
   str = str.toLowerCase();

   for (let char of str) {
      let chat_index = alphabet.indexOf(char);
      if (chat_index !== -1) {
         new_array[chat_index]++;
      }
   }
   alphabet.split('').forEach((char, i) => {
      const value = new_array[i];
      console.log(`${char} : ${value}`);
   })
}

const example_str = 'Hello, amazing world!';
build_dictionary(example_str);

